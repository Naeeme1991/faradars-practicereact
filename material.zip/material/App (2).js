import React from "react";
import logo from "./logo.svg";
import "./App.css";
import { Typography, Container, Grid, Paper } from "@mui/material";
import { pink } from "@mui/material/colors";

function App() {
  return (
    <Container maxWidth="lg">
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

          <Typography variant="h4" color={pink[400]} component="div">
            Material UI React
          </Typography>

          <Grid container spacing={4} justifyContent="center">
            <Grid item xs={12} md={6} lg={4}>
              <Paper style={{ height: 75, width: "100%" }} />
            </Grid>
            <Grid item xs={12} md={6} lg={4}>
              <Paper style={{ height: 75, width: "100%" }} />
            </Grid>
            <Grid item xs={12} md={6} lg={4}>
              <Paper style={{ height: 75, width: "100%" }} />
            </Grid>
          </Grid>
        </header>
      </div>
    </Container>
  );
}

export default App;
