import React, { useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import { Button, ButtonGroup, Checkbox, TextField } from "@mui/material";
import { Save as SaveIcon, Delete as DeleteIcon } from "@mui/icons-material";
import { orange, pink } from "@mui/material/colors";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: orange[400],
    },
    secondary: {
      main: pink[400],
    },
  },
});

const ColorButton = (props) => {
  const { title } = props;

  const style = {
    background: "linear-gradient(45deg, #FE6B8B, #FF8E53)",
    border: 0,
    borderRadius: 3,
    color: "white",
    height: 48,
    padding: "0 30px",
  };

  return <Button sx={style}>{title}</Button>;
};

function App() {
  const [isChecked, setIsChecked] = useState(false);

  const handleClick = () => {
    alert("Save clicked!");
  };

  const handleCheckboxChange = (e) => {
    const new_value = e.target.checked;

    setIsChecked(new_value);
  };

  return (
    <ThemeProvider theme={theme}>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

          <p style={{ color: `${theme.palette.primary.main}` }}>Faradars</p>

          <ColorButton title="Tests styled button" />

          <TextField
            variant="filled"
            color="secondary"
            label="First name"
            placeholder="input your name"
            type="password"
          />

          <div>
            <Checkbox
              size="large"
              color="success"
              checked={isChecked}
              onChange={handleCheckboxChange}
            />

            <p>{`${isChecked}`}</p>
          </div>

          <ButtonGroup variant="contained" size="large" color="primary">
            <Button startIcon={<SaveIcon />} onClick={handleClick}>
              Save
            </Button>
            <Button
              startIcon={<DeleteIcon />}
              onClick={() => alert("Delete clicked!")}
            >
              Delete
            </Button>
          </ButtonGroup>
        </header>
      </div>
    </ThemeProvider>
  );
}

export default App;
